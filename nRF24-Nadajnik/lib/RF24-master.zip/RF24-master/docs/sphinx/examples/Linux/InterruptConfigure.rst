InterruptConfigure.cpp
======================

.. literalinclude:: ../../../../examples_linux/interruptConfigure.cpp
    :lines: 7-
    :linenos:
    :lineno-match:
